const bcrypt = require('bcryptjs');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient('https://your-project-id.supabase.co', 'public-anon-key');

const validateInput = require('../utils/validateInput');

exports.register = async (req, res) => {
    const { username, email, password } = req.body;
    const validation = validateInput(username, email, password);
    if (!validation.valid) return res.status(400).json({ error: validation.message });

    const { data: existingUser } = await supabase
        .from('users')
        .select('*')
        .or(`username.eq.${username.toLowerCase()},email.eq.${email.toLowerCase()}`);

    if (existingUser.length > 0) {
        return res.status(400).json({ error: 'Username or email already exists' });
    }

    const salt = await bcrypt.genSalt(12);
    const hash = await bcrypt.hash(password, salt);

    const { error } = await supabase
        .from('users')
        .insert([{ username: username.toLowerCase(), display_name: username, email: email.toLowerCase(), password_hash: hash }]);

    if (error) return res.status(500).json({ error: 'Error creating user' });

    res.json({ message: 'User registered successfully' });
};

exports.login = async (req, res) => {
    const { identifier, password } = req.body;
    const field = identifier.includes('@') ? 'email' : 'username';

    const { data: user } = await supabase
        .from('users')
        .select('*')
        .eq(field, identifier.toLowerCase())
        .single();

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        return res.status(401).json({ error: 'Invalid username/email or password' });
    }

    req.session.user = { id: user.id, username: user.username };
    res.json({ message: 'Login successful' });
};

exports.logout = (req, res) => {
    req.session.destroy(() => {
        res.clearCookie('connect.sid');
        res.json({ message: 'Logged out' });
    });
};

exports.getDashboard = (req, res) => {
    res.json({ message: `Welcome, ${req.session.user.username}!` });
};
