module.exports = (username, email, password) => {
    const usernameRegex = /^(?!.*[_-]{2})[a-zA-Z0-9](?:[a-zA-Z0-9_-]{1,28}[a-zA-Z0-9])?$/;
    const emailRegex = /^[^@\s]{1,64}@[^@\s]+\.[^@\s]+$/;
    const commonPasswords = ['password', '123456', '12345678'];

    if (!usernameRegex.test(username)) {
        return { valid: false, message: 'Invalid username' };
    }
    if (!emailRegex.test(email)) {
        return { valid: false, message: 'Invalid email address' };
    }
    if (password.length < 8 || password.length > 128) {
        return { valid: false, message: 'Password must be 8-128 characters long' };
    }
    if (commonPasswords.includes(password.toLowerCase())) {
        return { valid: false, message: 'Password is too common' };
    }
    if (password.toLowerCase().includes(username.toLowerCase()) || password.toLowerCase().includes(email.split('@')[0].toLowerCase())) {
        return { valid: false, message: 'Password too similar to username/email' };
    }
    return { valid: true };
};
