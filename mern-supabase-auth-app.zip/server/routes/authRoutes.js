const express = require('express');
const { register, login, logout, getDashboard } = require('../controllers/authController');
const requireAuth = require('../middleware/requireAuth');
const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/logout', logout);
router.get('/dashboard', requireAuth, getDashboard);

module.exports = router;
